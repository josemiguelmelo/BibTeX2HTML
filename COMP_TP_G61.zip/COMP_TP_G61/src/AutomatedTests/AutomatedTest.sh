#!/bin/bash

echo ""
echo "----------------------------------------"
echo "-------- JavaCC Parser Compile  --------"
echo "----------------------------------------"
echo ""



echo ""
echo ""
echo "----------------------------------------"
echo "--- Compiling NO Error&Warning File ----"
echo "----------------------------------------"
echo ""

java -jar BibTex.jar examples/files/correctExample.bib examples/files/correctExample.html

echo ""
echo "------------------------------------------"
echo "------ Compiling ONLY Warning file ------"
echo "------------------------------------------"
echo ""

java -jar BibTex.jar examples/files/warningExample.bib examples/files/warningExample.html


echo ""
echo "------------------------------------------"
echo "------ Compiling Error&Warning file ------"
echo "------------------------------------------"
echo ""

java -jar BibTex.jar examples/files/errorWarningExample.bib examples/files/errorWarningExample.html


echo ""
echo "-----------------------------------------"
echo "----------- Compiling Bug file ----------"
echo "-----------------------------------------"
echo ""


java -jar BibTex.jar examples/files/bugExample.bib examples/files/bugExample.html



echo ""
echo "-----------------------------------------"
echo "------- Compiling Not Found file --------"
echo "-----------------------------------------"
echo ""


java -jar BibTex.jar examples/files/notFound.bib examples/files/notFound.html


echo ""
echo ""